
public class Bill {
	public int bill;
	public float cost;
	
	public float getCost(){
		return cost;
	}
	public int getBill(){
		return bill;
	}

}

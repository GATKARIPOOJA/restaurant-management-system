
public class Manager {
	void initialorder()
	{
		System.out.println("Display the food item for initialorder");
	}
 void receivecomplaint()
 {
	 System.out.println("It receives the complaint from the customer");
 }
 void receivebill()
 {
	 System.out.println("Manager receives the bill from customer");
 }
}


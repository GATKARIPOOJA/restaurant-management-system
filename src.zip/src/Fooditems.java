
public class Fooditems {
public String itemName;
public int itemId;
public int price;
public int getitemId(){
	return itemId;
}
public String getitemName(){
	return itemName;
}
public int getprice(){
	return price;
}
}
